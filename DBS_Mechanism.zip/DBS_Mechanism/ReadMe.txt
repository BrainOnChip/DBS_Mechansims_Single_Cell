To model the effect of DBS on Vim, SNr, and STN, one can simply run 'TM_DBS_Vim.m','TM_DBS_SNr.m','TM_DBS_STN.m', respectively.

Within each mfile, the frequency of DBS can be changed.

'DBS_Plasticity.m' incoporates the Tsodyks-Markram model of short-term synaptic plasticity to create total pres-syanptic current to the model neuron

Details of each file are provided as comments.